# Vaultpy
A module to parse injected [Vault](https://www.vaultproject.io/) secrets and track their usage with Datadog.

## Requirements
- Local Datadog agent
- Environment variables to access it

## Usage

